# SynthesisOne WhatsApp Bot v2.0

Puente de prueba entre SynthesisOne y WhatsApp.

## Persistencia

Usa `RemoteAuth` de whatsapp-web.js 1.34.7 con un Store propio. El ZIP temporal de sesión se cifra con AES-256-GCM y se guarda en un bucket privado de Supabase Storage. Al reiniciar/deployar, RemoteAuth puede descargar y restaurar la sesión remota.

RemoteAuth define el Store remoto con `sessionExists`, `save`, `extract` y `delete`, y exige un backup de al menos 60 s. Esta versión utiliza 5 minutos y además fuerza un guardado cuando WhatsApp llega a `ready`.

## Supabase

En Render configura `SUPABASE_URL` y `SUPABASE_SECRET_KEY`. En proyectos antiguos también se acepta `SUPABASE_SERVICE_ROLE_KEY`. La clave secreta es solo para el servidor; nunca debe ir al repositorio, navegador o APK.

Ejecuta `SUPABASE_SESSION_SETUP.sql` una sola vez. El bucket privado `whatsapp-sessions` se crea automáticamente.

## Wakeup

El Web Service Free de Render puede apagarse tras 15 minutos sin tráfico entrante. El Blueprint incluye un Render Cron cada 5 minutos que hace `GET /wake` y por eso genera tráfico entrante desde fuera del Web Service. El Cron es de pago y Render documenta un mínimo mensual de $1 para un Cron Job.

El wakeup reduce el riesgo de suspensión por inactividad, pero Render Free puede reiniciar la instancia en cualquier momento. La sesión remota en Supabase cubre ese reinicio.

## Seguridad

- Webhook HMAC V2 con timestamp y tolerancia de 5 minutos.
- Firma legacy aceptada para compatibilidad.
- Idempotencia persistida en Supabase mediante `event_id`.
- Bucket de sesión privado y contenido de sesión cifrado.
- Los webhooks no contienen secretos del cliente.
- El endpoint `/wake` está protegido por `KEEPALIVE_TOKEN`.

## WhatsApp

El bot ofrece QR y pairing code. El pairing code solo se solicita cuando WhatsApp Web reporta `UNPAIRED` o `UNPAIRED_IDLE`.

La integración usa `whatsapp-web.js`, que automatiza WhatsApp Web y no es la API oficial de Meta. Puede existir riesgo de restricciones por parte de WhatsApp. Para operación comercial crítica debe evaluarse la plataforma oficial de WhatsApp Business.
