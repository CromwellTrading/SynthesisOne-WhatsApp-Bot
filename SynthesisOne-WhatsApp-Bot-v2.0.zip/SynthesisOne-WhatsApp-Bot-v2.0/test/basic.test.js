const assert = require('node:assert/strict')
const test = require('node:test')
const crypto = require('node:crypto')
const { normalizeWhatsAppNumber, isLicensePurchase } = require('../src/format')
const { hmacHex, verifyWebhook } = require('../src/security')

test('normalizes Cuban 8-digit number', () => assert.equal(normalizeWhatsAppNumber('59190241', '53'), '5359190241'))
test('license comparison uses amount and receiver, without commission arithmetic', () => {
  const config = { licensePriceAmount: 28000, licenseCurrency: 'CUP', licenseReceiverAccounts: ['9227069995328054'] }
  assert.equal(isLicensePurchase({ amount: 28000, currency: 'CUP', receiver_account: '9227069995328054', commission: 500 }, config), true)
})
test('HMAC V2 verifies exact body and timestamp', () => {
  const body = JSON.stringify({ x: 1 })
  const ts = Math.floor(Date.now() / 1000)
  const secret = 'secret'
  const sig = hmacHex(`${ts}.${body}`, secret)
  assert.equal(verifyWebhook({ body, headers: { 'x-webhook-signature-v2': sig, 'x-webhook-timestamp': String(ts) }, secret, toleranceSec: 300 }).ok, true)
  assert.equal(verifyWebhook({ body: body + 'x', headers: { 'x-webhook-signature-v2': sig, 'x-webhook-timestamp': String(ts) }, secret, toleranceSec: 300 }).ok, false)
  assert.equal(crypto.createHash('sha256').update('x').digest('hex').length, 64)
})
