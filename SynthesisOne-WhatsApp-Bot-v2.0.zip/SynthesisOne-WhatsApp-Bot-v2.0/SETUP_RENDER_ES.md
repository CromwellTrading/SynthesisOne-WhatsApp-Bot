# SynthesisOne WhatsApp Bot v2.0 — pasos

## A. Supabase

1. Abre tu proyecto Supabase, el mismo de SynthesisOne.
2. `Settings → API Keys`.
3. Copia `Project URL` a `SUPABASE_URL`.
4. Copia la clave `Secret` (`sb_secret_...`) a `SUPABASE_SECRET_KEY`.
5. Si tu proyecto todavía usa las claves antiguas, puedes usar `service_role` en `SUPABASE_SERVICE_ROLE_KEY`.
6. Ejecuta `SUPABASE_SESSION_SETUP.sql` en SQL Editor.

La clave secreta de Supabase tiene privilegios elevados y jamás debe publicarse. Supabase recomienda usarla solo en componentes de servidor controlados.

## B. Render — Web Service

Conserva tu `ADMIN_SECRET` actual.

Conserva el `SYNTHESISONE_WEBHOOK_SECRET` del cliente SynthesisOne que quieres probar.

Añade:

- `SUPABASE_URL`
- `SUPABASE_SECRET_KEY`
- `WHATSAPP_SESSION_ENCRYPTION_KEY`
- `KEEPALIVE_TOKEN`
- `LICENSE_RECEIVER_ACCOUNTS=9227069995328054`

El Blueprint puede generar automáticamente `WHATSAPP_SESSION_ENCRYPTION_KEY` y `KEEPALIVE_TOKEN`. Si haces las variables manualmente, `WHATSAPP_SESSION_ENCRYPTION_KEY` debe tener 64 hex chars.

## C. Render — Cron de wakeup

El `render.yaml` trae un Cron `synthesisone-whatsapp-wakeup` cada 5 minutos. Los Cron Jobs de Render se cobran por el tiempo de ejecución y tienen un mínimo mensual documentado de $1.

Si tu servicio existente no está administrado por Blueprint, crea el Cron manualmente con:

Schedule: `*/5 * * * *`

Command: `node src/keepalive.js`

Variables:

`KEEPALIVE_TARGET_URL=https://synthesisone-whatsapp-bot.onrender.com`
`KEEPALIVE_TOKEN=<mismo token del Web Service>`
`KEEPALIVE_PATH=/wake`

## D. Primer vínculo

Después del cambio a RemoteAuth no asumas que la sesión anterior de LocalAuth se puede recuperar. Haz una vinculación inicial con QR.

Abre `/admin`, introduce `ADMIN_SECRET`, usa `Mostrar QR` y escanea.

Los logs que buscamos son:

`authenticated`
`ready`
`remote_session_saved`

Y en el panel:

`ready=true`
`remoteSession.exists=true`

## E. Después de un restart

No escanees otro QR de inmediato. Espera a que RemoteAuth consulte Supabase y restaure la sesión.
